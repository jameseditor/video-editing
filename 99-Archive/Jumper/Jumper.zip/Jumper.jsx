// ==========================================
// =                                        =
// =            JUMPER FRONTEND             =
// =                                        =
// ==========================================

// Check if the global object `$` is undefined, and if so, define it.
if (typeof($) == 'undefined') {
    $ = {};  // Initialize the global object `$`.
}

// Extend the `$` object with a custom `_ext` object that contains our utility functions.
$._ext = {
    // Evaluate a file given its path, and catch any exceptions that occur during evaluation.
    evalFile: function(path) {
        try {
            $.writeln("Evaluating file at path: " + path);  // Logging the path of the file to be evaluated.
            $.evalFile(path);  // Evaluate the specified JSX file.
            $.writeln("File evaluated successfully: " + path);  // Log success message.
        } catch (e) {
            // Log the error to the console and alert the user.
            var errorMessage = "Exception occurred while evaluating file: " + e;
            $.writeln(errorMessage);  // Log error to the console.
            alert(errorMessage);  // Display error alert to the user.
        }
    },

    // Evaluate all `.jsx` files in the specified folder.
    evalFiles: function(jsxFolderPath) {
        $.writeln("Evaluating all JSX files in folder: " + jsxFolderPath);  // Log the folder path.
        var folder = new Folder(jsxFolderPath);  // Create a Folder object.
        if (folder.exists) {  // Check if the folder exists.
            var jsxFiles = folder.getFiles("*.jsx");  // Get all `.jsx` files in the folder.
            $.writeln(jsxFiles.length + " JSX files found.");  // Log the number of files found.
            for (var i = 0; i < jsxFiles.length; i++) {  // Loop through each file.
                var jsxFile = jsxFiles[i];
                $.writeln("Evaluating file: " + jsxFile.fsName);  // Log the file name.
                $._ext.evalFile(jsxFile);  // Evaluate the file.
            }
            $.writeln("All files evaluated successfully.");  // Log completion message.
            return true;  // Return true indicating success.
        }
        $.writeln("Folder does not exist: " + jsxFolderPath);  // Log error if the folder doesn't exist.
        return false;  // Return false indicating failure.
    },

    // Entry-point function to call scripts more easily & reliably from JSON strings.
    callScript: function(dataStr) {
        try {
            $.writeln("Received data string: " + dataStr);  // Log the input data string.
            var dataObj = JSON.parse(decodeURIComponent(dataStr));  // Decode and parse the JSON string.
            $.writeln("Parsed data object: " + JSON.stringify(dataObj));  // Log the parsed data object.

            // Validate the necessary properties in the data object.
            if (
                !dataObj ||
                !dataObj.namespace ||
                !dataObj.scriptName ||
                !dataObj.args
            ) {
                throw new Error('Did not provide all needed info to callScript!');  // Throw error if validation fails.
            }

            $.writeln("Calling script: " + dataObj.namespace + "." + dataObj.scriptName);  // Log the script being called.
            // Call the specified JSX function with provided arguments.
            var result = $[dataObj.namespace][dataObj.scriptName].apply(
                null,
                dataObj.args
            );
            $.writeln("Script executed successfully, result: " + result);  // Log the result of the script execution.

            // Build the payload object to return.
            var payload = {
                err: 0,  // No error.
                result: result  // The result from the script execution.
            };
            return encodeURIComponent(JSON.stringify(payload));  // Return the payload as an encoded JSON string.
        } catch (err) {
            // Catch any error, log it, and return it in the payload.
            var errorMessage = "Error occurred in callScript: " + err.message;
            $.writeln(errorMessage);  // Log the error message.
            var payload = {
                err: err.message  // Include the error message in the payload.
            };
            return encodeURIComponent(JSON.stringify(payload));  // Return the error payload as an encoded JSON string.
        }
    }
};