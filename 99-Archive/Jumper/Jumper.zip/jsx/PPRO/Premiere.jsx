// ==========================================
// =                                        =
// =            JUMPER FRONTEND             =
// =                                        =
// ==========================================

// time display types

var TIMEDISPLAY_24Timecode = 100;
var TIMEDISPLAY_25Timecode = 101;
var TIMEDISPLAY_2997DropTimecode = 102;
var TIMEDISPLAY_2997NonDropTimecode = 103;
var TIMEDISPLAY_30Timecode = 104;
var TIMEDISPLAY_50Timecode = 105;
var TIMEDISPLAY_5994DropTimecode = 106;
var TIMEDISPLAY_5994NonDropTimecode = 107;
var TIMEDISPLAY_60Timecode = 108;
var TIMEDISPLAY_Frames = 109;
var TIMEDISPLAY_23976Timecode = 110;
var TIMEDISPLAY_16mmFeetFrames = 111;
var TIMEDISPLAY_35mmFeetFrames = 112;
var TIMEDISPLAY_48Timecode = 113;
var TIMEDISPLAY_AudioSamplesTimecode = 200;
var TIMEDISPLAY_AudioMsTimecode = 201;

var frameRateMap = {};
frameRateMap[TIMEDISPLAY_24Timecode] = 24.0;
frameRateMap[TIMEDISPLAY_25Timecode] = 25.0;
frameRateMap[TIMEDISPLAY_2997DropTimecode] = 29.97;
frameRateMap[TIMEDISPLAY_2997NonDropTimecode] = 29.97;
frameRateMap[TIMEDISPLAY_30Timecode] = 30.0;
frameRateMap[TIMEDISPLAY_50Timecode] = 50.0;
frameRateMap[TIMEDISPLAY_5994DropTimecode] = 59.94;
frameRateMap[TIMEDISPLAY_5994NonDropTimecode] = 59.94;
frameRateMap[TIMEDISPLAY_60Timecode] = 60.0;
frameRateMap[TIMEDISPLAY_23976Timecode] = 23.976;
frameRateMap[TIMEDISPLAY_48Timecode] = 48.0;

var KF_Interp_Mode_Linear = 0;
var KF_Interp_Mode_Hold = 4;
var KF_Interp_Mode_Bezier = 5;
var KF_Interp_Mode_Time = 6;

// field type constants

var FIELDTYPE_Progressive = 0;
var FIELDTYPE_UpperFirst = 1;
var FIELDTYPE_LowerFirst = 2;

// audio channel types

var AUDIOCHANNELTYPE_Mono = 0;
var AUDIOCHANNELTYPE_Stereo = 1;
var AUDIOCHANNELTYPE_51 = 2;
var AUDIOCHANNELTYPE_Multichannel = 3;
var AUDIOCHANNELTYPE_4Channel = 4;
var AUDIOCHANNELTYPE_8Channel = 5;

// vr projection type

var VRPROJECTIONTYPE_None = 0;
var VRPROJECTIONTYPE_Equirectangular = 1;

// vr stereoscopic type

var VRSTEREOSCOPICTYPE_Monoscopic = 0;
var VRSTEREOSCOPICTYPE_OverUnder = 1;
var VRSTEREOSCOPICTYPE_SideBySide = 2;

// constants used when clearing cache

var MediaType_VIDEO = "228CDA18-3625-4d2d-951E-348879E4ED93"; // Magical constants from Premiere Pro's internal automation.
var MediaType_AUDIO = "80B8E3D5-6DCA-4195-AEFB-CB5F407AB009";
var MediaType_ANY = "FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF";

var MediaType_Audio = 0;	// Constants for working with setting value.
var MediaType_Video = 1;

var Colorspace_601 = 0;
var Colorspace_709 = 1;
var Colorspace_2020 = 2;
var Colorspace_2100HLG = 3;

var BitPrecision_8bit = 0;
var BitPrecision_10bit = 1;
var BitPrecision_Float = 2;
var BitPrecision_HDR = 3;

var NOT_SET = "-400000";

var projectImportsStatus = "STALE";
var numItemsInProjectState = 0;

$._PPP_ = {
    getVersionInfo: function () {
        return 'PPro ' + app.version + 'x' + app.build;
    },

    getUserName: function () {
        var userName = "User name not found.";
        var homeDir = new File('~/');
        if (homeDir) {
            userName = homeDir.displayName;
            homeDir.close();
        }
        return userName;
    },

    keepPanelLoaded: function () {
        app.setExtensionPersistent("Jumper", 0); // 0, while testing (to enable rapid reload); 1 for "Never unload me, even when not visible."
        return true;
    },

    updateAllProjectItems: function () {
        var numItems = app.project.rootItem.children.numItems;
        for (var i = 0; i < numItems; i++) {
            var currentItem = app.project.rootItem.children[i];
            if (currentItem) {
                currentItem.refreshMedia();
            }
        }
    },

    getSep: function () {
        if (Folder.fs === 'Macintosh') {
            return '/';
        } else {
            return '\\';
        }
    },

    saveProject: function () {
        app.project.save();
    },

    projectPanelSelectionChanged: function (eventObj) { // Note: This message is also triggered when the user opens or creates a new project.
        var message = "";
        var projectItems = eventObj;
        if (projectItems) {
            if (projectItems.length) {
                var remainingArgs = projectItems.length;
                var view = eventObj.viewID;
                message = remainingArgs + " items selected: ";

                for (var i = 0; i < projectItems.length; i++) {		// Concatenate selected project item names, into message.
                    message += projectItems[i].name;
                    remainingArgs--;
                    if (remainingArgs > 1) {
                        message += ', ';
                    }
                    if (remainingArgs === 1) {
                        message += ", and ";
                    }
                    if (remainingArgs === 0) {
                        message += ".";
                    }
                }
            } else {
                message = 'No items selected.';
            }
        }
        $._PPP_.updateEventPanel(message);
    },

    // Specific to Jumper
    registerProjectPanelSelectionChangedFxn: function (callback) {
        //app.setSDKEventMessage("registerProjectPanelSelectionChangedFxn triggered", 'info');
        app.bind("onSourceClipSelectedInProjectPanel", $._PPP_.setShouldRefreshProjectImports);
        return true;
    },

    // Specific to Jumper
    registerItemsAddedToProjectFxn: function () {
        //app.setSDKEventMessage("registerItemsAddedToProjectFxn triggered", 'info');
        app.bind("onItemsAddedToProjectSuccess", $._PPP_.setShouldRefreshProjectImports);
        return true;
    },

    searchForBinWithName: function (nameToFind) {
        // deep-search a folder by name in project
        var deepSearchBin = function (inFolder) {
            if (inFolder && inFolder.name === nameToFind && inFolder.type === 2) {
                return inFolder;
            } else {
                for (var i = 0; i < inFolder.children.numItems; i++) {
                    if (inFolder.children[i] && inFolder.children[i].type === 2) {
                        var foundBin = deepSearchBin(inFolder.children[i]);
                        if (foundBin) {
                            return foundBin;
                        }
                    }
                }
            }
        };
        return deepSearchBin(app.project.rootItem);
    },

    getnumAEProjectItems: function () {
        var bt = new BridgeTalk();
        bt.target = 'aftereffects';
        bt.body = 'alert("Items in AE project: " + app.project.rootFolder.numItems);app.quit();';
        bt.send();
    },

    updateEventPanel: function (message) {
        //app.setSDKEventMessage(message, 'info');
        /*app.setSDKEventMessage('Here is some information.', 'info');
        app.setSDKEventMessage('Here is a warning.', 'warning');
        app.setSDKEventMessage('Here is an error.', 'error');  // Very annoying; use sparingly.*/
    },

    searchBinForProjItemByName: function (i, containingBin, nameToFind) {
        for (var j = i; j < containingBin.children.numItems; j++) {
            var currentChild = containingBin.children[j];
            if (currentChild) {
                if (currentChild.type === ProjectItemType.BIN) {
                    return $._PPP_.searchBinForProjItemByName(j, currentChild, nameToFind); // warning; recursion!
                } else {
                    if (currentChild.name === nameToFind) {
                        return currentChild;
                    } else {
                        currentChild = currentChild.children[j + 1];
                        if (currentChild) {
                            return $._PPP_.searchBinForProjItemByName(0, currentChild, nameToFind);
                        }
                    }
                }
            }
        }
    },

    dumpProjectItemXMP: function (projectItem, outPath) {
        var xmpBlob = projectItem.getXMPMetadata();
        var outFileName = projectItem.name + '.xmp';
        var completeOutputPath = outPath + $._PPP_.getSep() + outFileName;
        var outFile = new File(completeOutputPath);

        if (outFile) {
            outFile.encoding = "UTF8";
            outFile.open("w", "TEXT", "????");
            outFile.write(xmpBlob.toString());
            outFile.close();
        }
    },

    dumpXMPFromAllProjectItems: function () {
        var numItemsInRoot = app.project.rootItem.children.numItems;
        if (numItemsInRoot > 0) {
            var outPath = Folder.selectDialog("Choose the output directory");
            if (outPath) {
                for (var i = 0; i < numItemsInRoot; i++) {
                    var currentItem = app.project.rootItem.children[i];
                    if (currentItem) {
                        if (currentItem.type == ProjectItemType.BIN) {
                            $._PPP_.walkAllBinsDumpingXMP(currentItem, outPath.fsName);
                        } else {
                            $._PPP_.dumpProjectItemXMP(currentItem, outPath.fsName);
                        }
                    }
                }
            }
        } else {
            $._PPP_.updateEventPanel("No project items found.");
        }
    },

    clearCache: function () {
        app.enableQE();
        qe.project.deletePreviewFiles(MediaType_ANY);
        $._PPP_.updateEventPanel("All video and audio preview files deleted.");
    },

    extractFileNameFromPath: function (fullPath) {
        var lastDot = fullPath.lastIndexOf(".");
        var lastSep = fullPath.lastIndexOf("/");
        if (lastDot > -1) {
            return fullPath.substr((lastSep + 1), (fullPath.length - (lastDot + 1)));
        } else {
            return fullPath;
        }
    },

    onProxyTranscodeJobComplete: function (jobID, outputFilePath) {
        var suffixAddedByPPro = '_1'; // You should really test for any suffix.
        var withoutExtension = outputFilePath.slice(0, -4); // trusting 3 char extension
        var lastIndex = outputFilePath.lastIndexOf(".");
        var extension = outputFilePath.substr(lastIndex + 1);
        var wrapper = [];
        wrapper[0] = outputFilePath;
        var nameToFind = 'Proxies generated by Jumper'; // Specific to Jumper
        var targetBin = $._PPP_.getPPPInsertionBin();
        if (targetBin) {
            app.project.importFiles(wrapper, true, null, false);
        }
        return true;
    },

    getPPPInsertionBin: function () {
        var nameToFind = "Here's where Jumper puts things."; // Specific to Jumper
        var targetBin = $._PPP_.searchForBinWithName(nameToFind);

        if (targetBin === undefined) {
            // If panel can't find the target bin, it creates it.
            app.project.rootItem.createBin(nameToFind);
            targetBin = $._PPP_.searchForBinWithName(nameToFind);
        }
        if (targetBin) {
            targetBin.select();
            return targetBin;
        } else {
            $._PPP_.updateEventPanel("Couldn't find or create a target bin.");
        }
        return true;
    },

    importMoGRT: function () {
        var activeSeq = app.project.activeSequence;
        if (activeSeq) {
            var filterString = "";
            if (Folder.fs === 'Windows') {
                filterString = "Motion Graphics Templates:*.mogrt";
            }
            var mogrtToImport = File.openDialog("Choose MoGRT",	// title
                filterString,	// filter available files?
                false);			// allow multiple?
            if (mogrtToImport) {
                var targetTime = activeSeq.getPlayerPosition();
                var vidTrackOffset = 0;
                var audTrackOffset = 0;
                var newTrackItem = activeSeq.importMGT(mogrtToImport.fsName,
                    targetTime.ticks,
                    vidTrackOffset,
                    audTrackOffset);
                if (newTrackItem) {
                    var moComp = newTrackItem.getMGTComponent();
                    if (moComp) {
                        var params = moComp.properties;
                        for (var z = 0; z < params.numItems; z++) {
                            var thisParam = params[z];
                            if (thisParam) {
                                $._PPP_.updateEventPanel('Parameter ' + (z + 1) + ' name: ' + thisParam.name + '.');
                            }
                        }
                        var srcTextParam = params.getParamForDisplayName("Source Text");
                        if (srcTextParam) {
                            var val = srcTextParam.getValue();
                            srcTextParam.setValue("New value set by Jumper!"); // Specific to Jumper
                        }
                    }
                }
            } else {
                $._PPP_.updateEventPanel('Unable to import specified .mogrt file.');
            }
        } else {
            $._PPP_.updateEventPanel('No active sequence.');
        }
        return true;
    },

    updateFrameRate: function () {
        var item = app.project.rootItem.children[0];
        if (item) {
            if ((item.type == ProjectItemType.FILE) || (item.type == ProjectItemType.CLIP)) {
                // If there is an item, and it's either a clip or file...
                item.setOverrideFrameRate(23.976);
            } else {
                $._PPP_.updateEventPanel('You cannot override the frame rate of bins or sequences.');
            }
        } else {
            $._PPP_.updateEventPanel("No project items found.");
        }
    },

    registerItemAddedFxn: function () {
        //app.setSDKEventMessage("registerItemAddedFxn triggered", 'info');
        app.onItemAddedToProjectSuccess = $._PPP_.setShouldRefreshProjectImports; // Specific to Jumper
        return true;
    },

    registerProjectChangedFxn: function () {
        //app.setSDKEventMessage("registerProjectChangedFxn triggered", 'info');
        app.bind('onProjectChanged', $._PPP_.setShouldRefreshProjectImports); // Specific to Jumper
        return true;
    },

    confirmPProHostVersion: function () {
        //app.setSDKEventMessage("confirmPProHostVersion triggered", 'info');
        var version = parseFloat(app.version);
        if (version < 14.0) {
            $._PPP_.updateEventPanel("Note: Jumper relies on features added in 14.0, but is currently running in " + version + "."); // Specific to Jumper
        }
        return true;
    },

    changeSeqTimeCodeDisplay: function () {
        var seq = app.project.activeSequence;
        if (seq) {
            var currentSeqSettings = app.project.activeSequence.getSettings();
            if (currentSeqSettings) {
                var oldVidSetting = currentSeqSettings.videoDisplayFormat;
                var timeAsText = seq.getPlayerPosition().getFormatted(currentSeqSettings.videoFrameRate, app.project.activeSequence.videoDisplayFormat);

                currentSeqSettings.videoDisplayFormat = oldVidSetting + 1;
                if (currentSeqSettings.videoDisplayFormat > TIMEDISPLAY_48Timecode) {	// clamp to valid values
                    currentSeqSettings.videoDisplayFormat = TIMEDISPLAY_24Timecode;
                }
                app.project.activeSequence.setSettings(currentSeqSettings);
                $._PPP_.updateEventPanel("Changed timecode display format for \'" + app.project.activeSequence.name + "\'.");
            }
        } else {
            $._PPP_.updateEventPanel("No active sequence.");
        }
    },

    consolidateDuplicates: function () {
        var result = app.project.consolidateDuplicates();
        $._PPP_.updateEventPanel("Duplicates consolidated in " + app.project.name + ".");
    },

    openProjectItemInSource: function () {
        var viewIDs = app.getProjectViewIDs();
        if (viewIDs) {
            for (var a = 0; a < app.projects.numProjects; a++) {
                var currentProject = app.getProjectFromViewID(viewIDs[a]);
                if (currentProject) {
                    if (currentProject.documentID === app.project.documentID) { // We're in the right project!
                        var selectedItems = app.getProjectViewSelection(viewIDs[a]);
                        if (selectedItems) {
                            for (var b = 0; b < selectedItems.length; b++) {
                                var currentItem = selectedItems[b];
                                if (currentItem) {
                                    if (currentItem.type !== ProjectItemType.BIN) { // For every selected item which isn't a bin or sequence...
                                        app.sourceMonitor.openProjectItem(currentItem);
                                    }
                                } else {
                                    $._PPP_.updateEventPanel("No item available.");
                                }
                            }
                        }
                    }
                } else {
                    $._PPP_.updateEventPanel("No project available.");
                }
            }
        } else {
            $._PPP_.updateEventPanel("No view IDs available.");
        }
    },

    reinterpretFootage: function () {
        var viewIDs = app.getProjectViewIDs();
        if (viewIDs) {
            for (var a = 0; a < app.projects.numProjects; a++) {
                var currentProject = app.getProjectFromViewID(viewIDs[a]);
                if (currentProject) {
                    if (currentProject.documentID === app.project.documentID) { // We're in the right project!
                        var selectedItems = app.getProjectViewSelection(viewIDs[a]);
                        if (selectedItems.length) {
                            for (var b = 0; b < selectedItems.length; b++) {
                                var currentItem = selectedItems[b];
                                if (currentItem) {
                                    if ((currentItem.type !== ProjectItemType.BIN) &&
                                        (currentItem.isSequence() === false)) {
                                        var interp = currentItem.getFootageInterpretation();
                                        if (interp) {
                                            interp.frameRate = 17.868;
                                            interp.pixelAspectRatio = 1.2121;
                                            currentItem.setFootageInterpretation(interp);
                                            $._PPP_.updateEventPanel("Changed frame rate and PAR for " + currentItem.name + ".");
                                        } else {
                                            $._PPP_.updateEventPanel("Unable to get interpretation for " + currentItem.name + ".");
                                        }
                                        var mapping = currentItem.getAudioChannelMapping;
                                        if (mapping) {
                                            mapping.audioChannelsType = AUDIOCHANNELTYPE_Stereo;
                                            mapping.audioClipsNumber = 1;
                                            mapping.setMappingForChannel(0, 4); // 1st param = channel index, 2nd param = source index
                                            mapping.setMappingForChannel(1, 5);
                                            currentItem.setAudioChannelMapping(mapping); // submit changed mapping object
                                            $._PPP_.updateEventPanel("Modified audio channel type and channel mapping for " + currentItem.name + ".");
                                        }
                                    }
                                } else {
                                    $._PPP_.updateEventPanel("No project item available.");
                                }
                            }
                        } else {
                            $._PPP_.updateEventPanel("No items selected.");
                        }
                    }
                } else {
                    $._PPP_.updateEventPanel("No project available.");
                }
            }
        } else {
            $._PPP_.updateEventPanel("No view IDs available.");
        }
    },

    // Specific to Jumper
    setLocale: function (localeFromCEP) {
        //app.setSDKEventMessage("setLocale triggered", 'info');
        $.locale = localeFromCEP;
        $._PPP_.updateEventPanel("ExtendScript Locale set to " + localeFromCEP + ".");
        return true;
    },

    // Specific to Jumper
    performCutDetection: function () {
        //app.setSDKEventMessage("performCutDetection triggered", 'info');
        var activeSeq = app.project.activeSequence;
        if (activeSeq) {
            var sel = activeSeq.getSelection();
            if (sel) {
                var action = 'ApplyCuts';	//'ApplyCuts', 'CreateMarkers'
                var shouldApplyCutsToLinkedAudio = true;
                var sensitivity = 'LowSensitivity'; //'LowSensitivity', 'MediumSensitivity', 'HighSensitivity'
                var result = activeSeq.performSceneEditDetectionOnSelection(action, shouldApplyCutsToLinkedAudio, sensitivity);
            } else {
                $._PPP_.updateEventPanel("performSceneEditDetectionOnSelection: Nothing selected, in sequence.");
            }
        } else {
            $._PPP_.updateEventPanel("performSceneEditDetectionOnSelection: No active sequence.");
        }
        return true;
    },

    // Specific to Jumper
    importSrtAddToCaptionTrack: function () {
        //app.setSDKEventMessage("importSrtAddToCaptionTrack triggered", 'info');
        var destBin = app.project.getInsertionBin();
        if (destBin) {
            var prevItemCount = destBin.children.numItems;

            var filterString = "";
            if (Folder.fs === 'Windows') {
                filterString = "All files:*.*";
            }
            if (app.project) {
                var importThese = [];
                var fileOrFilesToImport = File.openDialog("Choose files to import", // title
                    filterString, // filter available files?
                    true); // allow multiple?
                if (fileOrFilesToImport) {
                    // We have an array of File objects; importFiles() takes an array of paths.
                    if (importThese) {
                        for (var i = 0; i < fileOrFilesToImport.length; i++) {
                            importThese[i] = fileOrFilesToImport[i].fsName;
                        }
                        var suppressWarnings = true;
                        var importAsStills = false;
                        app.project.importFiles(importThese,
                            suppressWarnings,
                            app.project.getInsertionBin(),
                            importAsStills);

                    } else {
                        $._PPP_.updateEventPanel("No files to import.");
                    }
                }

                if (importThese) {
                    var newItemCount = destBin.children.numItems;
                    if (newItemCount > prevItemCount) {
                        var importedSRT = destBin.children[(newItemCount - 1)];
                        if (importedSRT) {
                            var activeSeq = app.project.activeSequence;
                            if (activeSeq) {
                                var startAtTime = 0;
                                var result = app.project.activeSequence.createCaptionTrack(importedSRT, startAtTime);
                            } else {
                                $._PPP_.updateEventPanel("No active sequence.");
                            }
                        } else {
                            $._PPP_.updateEventPanel("Whoops, couldn't find imported .srt file.");
                        }
                    } else {
                        $._PPP_.updateEventPanel("Whoa, no new item? How'd THAT happen?!");
                    }
                } else {
                    $._PPP_.updateEventPanel("importFiles() failed to import, OR return an error message. I quit!");
                }
            } else {
                $._PPP_.updateEventPanel("No destination bin available");
            }
        }
        return true;
    },

    // Specific to Jumper
    checkMacFileType: function (file) {
        //app.setSDKEventMessage("checkMacFileType triggered", 'info');
        if (!file instanceof Folder) {
            return true;
        }

        var index = file.name.lastIndexOf(".");
        var ext = file.name.substring(index + 1);

        if (ext == "xml" || ext == "XML") {
            return true;
        } else {
            return false;
        }
    },

    // Specific to Jumper
    getNumberOfProjectItems: function () {
        //app.setSDKEventMessage("getNumberOfProjectItems triggered", 'info');
        var project = app.project;
        var numItems = 0;

        function countTotalItems(item) {
            if (item.type === ProjectItemType.BIN) {
                var itemsInBin = item.children.numItems;
                numItems += itemsInBin;
                for (var j = 0; j < itemsInBin; j++) {
                    countTotalItems(item.children[j]);
                }
            }
        }

        if (project) {
            var rootBin = project.rootItem;
            var itemsInRoot = rootBin.children.numItems;
            numItems += itemsInRoot;
            for (var i = 0; i < itemsInRoot; i++) {
                countTotalItems(rootBin.children[i]);
            }
        }

        return numItems;
    },
    isReady: function () {
        return "OK"
    },
    escapeForJSON: function (str) {
        var result = "";
        for (var i = 0; i < str.length; i++) {
            var chr = str.charAt(i);
            if (chr === '\\') {
                result += '\\\\';
            } else if (chr === '"') {
                result += '\\"';
            } else {
                result += chr;
            }
        }
        return result;
    },
    getMulticamClipMapping: function () {
        var project = app.project;
        var jsonString = '{"multicamClips":[';
        var isFirstMulticam = true;

        function getMappingFor(item) {
            if (item.type === ProjectItemType.BIN) {
                for (var j = 0; j < item.children.numItems; j++) {
                    getMappingFor(item.children[j]);
                }
            } else if (item.type === ProjectItemType.CLIP && item.isMulticamClip()) {
                var clipName = item.name;
                var numSequences = app.project.sequences.numSequences;

                var sourceMediaPathsObj = {};
                var videoClipsInfo = [];
                var audioClipsInfo = [];

                for (var i = 0; i < numSequences; i++) {
                    var sequence = app.project.sequences[i];
                    if (sequence.name === item.name) {
                        var videoTracks = sequence.videoTracks;
                        for (var k = 0; k < videoTracks.numTracks; k++) {
                            var videoClips = videoTracks[k].clips;
                            for (var m = 0; m < videoClips.numItems; m++) {
                                var videoClip = videoClips[m];
                                var videoClipStartSeconds = videoClip.start.seconds;
                                var videoClipProjItem = videoClip.projectItem;
                                var vidClipPath = videoClipProjItem.getMediaPath();
                                sourceMediaPathsObj[vidClipPath] = true;

                                // Collect the video clip info
                                videoClipsInfo.push({
                                    'mediaPath': vidClipPath,
                                    'startSeconds': videoClipStartSeconds
                                });
                            }
                        }
                        var audioTracks = sequence.audioTracks;
                        for (var l = 0; l < audioTracks.numTracks; l++) {
                            var audioClips = audioTracks[l].clips;
                            for (var n = 0; n < audioClips.numItems; n++) {
                                var audioClip = audioClips[n];
                                var audioClipStartSeconds = audioClip.start.seconds;
                                var audioClipProjItem = audioClip.projectItem;
                                var audioClipPath = audioClipProjItem.getMediaPath();
                                sourceMediaPathsObj[audioClipPath] = true;

                                // Collect the audio clip info
                                audioClipsInfo.push({
                                    'mediaPath': audioClipPath,
                                    'startSeconds': audioClipStartSeconds
                                });
                            }
                        }
                    }
                }

                var clipJson = '{';
                clipJson += '"clipName":"' + $._PPP_.escapeForJSON(clipName) + '",';
                clipJson += '"sourceMediaPaths":[';

                var isFirstPath = true;
                for (var path in sourceMediaPathsObj) {
                    if (sourceMediaPathsObj.hasOwnProperty(path)) {
                        if (!isFirstPath) {
                            clipJson += ',';
                        }
                        clipJson += '"' + $._PPP_.escapeForJSON(path) + '"';
                        isFirstPath = false;
                    }
                }
                clipJson += '],';

                // Add videoClips array
                clipJson += '"videoClips":[';
                var isFirstVideoClip = true;
                for (var idx = 0; idx < videoClipsInfo.length; idx++) {
                    if (!isFirstVideoClip) {
                        clipJson += ',';
                    }
                    var vidClipInfo = videoClipsInfo[idx];
                    clipJson += '{';
                    clipJson += '"mediaPath":"' + $._PPP_.escapeForJSON(vidClipInfo.mediaPath) + '",';
                    clipJson += '"startSeconds":' + vidClipInfo.startSeconds;
                    clipJson += '}';
                    isFirstVideoClip = false;
                }
                clipJson += '],';

                // Add audioClips array
                clipJson += '"audioClips":[';
                var isFirstAudioClip = true;
                for (var idx = 0; idx < audioClipsInfo.length; idx++) {
                    if (!isFirstAudioClip) {
                        clipJson += ',';
                    }
                    var audioClipInfo = audioClipsInfo[idx];
                    clipJson += '{';
                    clipJson += '"mediaPath":"' + $._PPP_.escapeForJSON(audioClipInfo.mediaPath) + '",';
                    clipJson += '"startSeconds":' + audioClipInfo.startSeconds;
                    clipJson += '}';
                    isFirstAudioClip = false;
                }
                clipJson += ']';

                clipJson += '}';

                if (!isFirstMulticam) {
                    jsonString += ',';
                }
                jsonString += clipJson;
                isFirstMulticam = false;
            }
        }

        if (project) {
            var rootBin = project.rootItem;
            for (var i = 0; i < rootBin.children.numItems; i++) {
                getMappingFor(rootBin.children[i]);
            }
        }

        jsonString += ']}';
        return jsonString;
    },
    getImportedVideos: function () {
        var project = app.project;
        var videos = [];

        function addVideosFromItem(item, bin) {
            if (item.type === ProjectItemType.BIN) {
                for (var j = 0; j < item.children.numItems; j++) {
                    addVideosFromItem(item.children[j], bin + item.name + "/");
                }
            } else if (item.type === ProjectItemType.CLIP) {
                var mediaPath = item.getMediaPath();
                if (mediaPath && !item.isOffline()) {
                    var escapedMediaPath = $._PPP_.escapeForJSON(mediaPath);
                    videos.push('{"mediaPath": "' + escapedMediaPath + '","bin": "' + bin + '"}');
                }
            }
        }

        if (project) {
            var rootBin = project.rootItem;
            for (var i = 0; i < rootBin.children.numItems; i++) {
                addVideosFromItem(rootBin.children[i], "/");
            }
        }

        projectImportsStatus = "STALE";
        return videos.join("_|&|#|e|_");
    },

    findMatchingProjectItemByItemName: function (mediaName) {
        //app.setSDKEventMessage("findMatchingProjectItem triggered", 'info');
        var matchingProjItems = [];

        function getMediaMatchingFilepath(item) {
            if (matchingProjItems.length > 0) {
                return;
            }
            if (item.type === ProjectItemType.BIN) {
                for (var j = 0; j < item.children.numItems; j++) {
                    getMediaMatchingFilepath(item.children[j]);
                }
            } else if (item.type === ProjectItemType.CLIP) {
                if (item.name === mediaName) {
                    matchingProjItems.push(item);
                }
            }
        }

        for (var b = 0; b < app.project.rootItem.children.numItems; b++) {
            var currentProjectItem = app.project.rootItem.children[b];
            if (matchingProjItems.length <= 0) {
                getMediaMatchingFilepath(currentProjectItem);
            }
        }

        if (matchingProjItems.length > 0) {
            return matchingProjItems[0];
        }
        return null;
    },

    // Specific to Jumper
    findMatchingProjectItem: function (mediaPath) {
        //app.setSDKEventMessage("findMatchingProjectItem triggered", 'info');
        var matchingProjItems = [];

        function getMediaMatchingFilepath(item) {
            if (matchingProjItems.length > 0) {
                return;
            }
            if (item.type === ProjectItemType.BIN) {
                for (var j = 0; j < item.children.numItems; j++) {
                    getMediaMatchingFilepath(item.children[j]);
                }
            } else if (item.type === ProjectItemType.CLIP) {
                if (item.getMediaPath() === mediaPath) {
                    matchingProjItems.push(item);
                }
            }
        }

        for (var b = 0; b < app.project.rootItem.children.numItems; b++) {
            var currentProjectItem = app.project.rootItem.children[b];
            if (matchingProjItems.length <= 0) {
                getMediaMatchingFilepath(currentProjectItem);
            }
        }

        if (matchingProjItems.length > 0) {
            return matchingProjItems[0];
        }
        return null;
    },

    // Specific to Jumper
    navigateToTimestamp: function (mediaPath, normalizedPath, timeString) {
        //app.setSDKEventMessage("navigateToTimestamp triggered", 'info');
        var projectItem = $._PPP_.findMatchingProjectItem(mediaPath);
        if (projectItem === null) {
            projectItem = $._PPP_.findMatchingProjectItem(normalizedPath);
        }
        if (projectItem) {
            app.enableQE();
            app.sourceMonitor.openProjectItem(projectItem);
            qe.source.player.startScrubbing();
            qe.source.player.scrubTo(timeString + ":00");
            qe.source.player.endScrubbing();
        }
        return true;
    },

    navigateToTimestampInMulticam: function (name, normalizedName, timeString, offsetSeconds) {
        var projectItem = $._PPP_.findMatchingProjectItemByItemName(name);
        if (projectItem === null) {
            projectItem = $._PPP_.findMatchingProjectItemByItemName(normalizedName);
        }
        if (projectItem) {
            app.enableQE();
            app.sourceMonitor.openProjectItem(projectItem);

            // Find the sequence associated with the project item
            var sequence = null;
            var numSequences = app.project.sequences.numSequences;
            for (var i = 0; i < numSequences; i++) {
                var seq = app.project.sequences[i];
                if (seq.name === projectItem.name) {
                    sequence = seq;
                    break;
                }
            }

            var frameRate = null;
            if (sequence !== null) {
                var videoDisplayFormat = sequence.videoDisplayFormat;
                frameRate = frameRateMap[videoDisplayFormat];
            }

            // Fallback: Try to get frame rate from projectItem
            if (!frameRate) {
                if (projectItem.getFootageInterpretation) {
                    var footageInterpretation = projectItem.getFootageInterpretation();
                    if (footageInterpretation && footageInterpretation.frameRate) {
                        frameRate = parseFloat(footageInterpretation.frameRate);
                    }
                }
            }

            var newTimecode = timeString + ":00";
            if (frameRate && offsetSeconds > 0) {
                newTimecode = $._PPP_.getTimecodeWithOffsetSeconds(timeString, frameRate, offsetSeconds);
            }

            qe.source.player.startScrubbing();
            qe.source.player.scrubTo(newTimecode);
            qe.source.player.endScrubbing();
        }

        return 'Computed newTimecode: ' + newTimecode + ', Frame rate: ' + frameRate;
    },

    // Specific to Jumper
    getSecondsFromTimestamp: function (ts) {
        //app.setSDKEventMessage("getSecondsFromTimestamp triggered", 'info');
        const delimiter = ts.indexOf(':') !== -1 ? ':' : ';';
        const parts = ts.split(delimiter);
        const hours = parseInt(parts[0], 10);
        const minutes = parseInt(parts[1], 10);
        const seconds = parseInt(parts[2], 10);
        return (hours * 3600) + (minutes * 60) + seconds;
    },
    // Specific to Jumper
    parseFractionalSeconds: function (duration, frameRate) {
        //app.setSDKEventMessage("parseFractionalSeconds triggered", 'info');
        const delimiter = duration.indexOf(':') !== -1 ? ':' : ';';
        const parts = duration.split(delimiter);
        const hours = parseInt(parts[0], 10);
        const minutes = parseInt(parts[1], 10);
        const seconds = parseInt(parts[2], 10);
        const frames = parseInt(parts[3], 10);

        const totalSeconds = (hours * 3600) + (minutes * 60) + seconds;
        const secondsPerTick = 1 / frameRate;
        const frameSeconds = frames * secondsPerTick;
        return totalSeconds + frameSeconds;
    },
    getTimecodeWithOffsetSeconds: function(ts, frameRate, seconds) {
        // ts is timestamp like HH:MM:SS, e.g. 01:22:14
        function padZero(num) {
            if (num < 10) {
                return '0' + num;
            } else {
                return '' + num;
            }
        }
        var tsParts = ts.split(":");
        var hours = parseInt(tsParts[0], 10);
        var minutes = parseInt(tsParts[1], 10);
        var secs = parseInt(tsParts[2], 10);
        // Calculate total seconds including the offset
        var totalSeconds = hours * 3600 + minutes * 60 + secs + seconds;

        var newHours = Math.floor(totalSeconds / 3600);
        totalSeconds -= newHours * 3600;
        var newMinutes = Math.floor(totalSeconds / 60);
        totalSeconds -= newMinutes * 60;
        var newSeconds = Math.floor(totalSeconds);
        var fractionalSeconds = totalSeconds - newSeconds;

        var frames = Math.floor(fractionalSeconds * frameRate + 0.0001); // Adjust for floating point errors

        // Handle possible rounding issues where frames equal or exceed frameRate
        if (frames >= frameRate) {
            frames = 0;
            newSeconds += 1;
            if (newSeconds >= 60) {
                newSeconds = 0;
                newMinutes += 1;
                if (newMinutes >= 60) {
                    newMinutes = 0;
                    newHours += 1;
                }
            }
        }

        var timecode = padZero(newHours) + ':' + padZero(newMinutes) + ':' + padZero(newSeconds) + ':' + padZero(frames);
        return timecode;
    },
    markInAndOut: function (mediaPath, normalizedPath, startTime, endTime, markMode, matchingFrameTime) {
        //app.setSDKEventMessage("markInAndOut triggered", 'info');
        var projItem = $._PPP_.findMatchingProjectItem(mediaPath)
        if (projItem === null) {
            projItem = $._PPP_.findMatchingProjectItem(normalizedPath)
        }
        return $._PPP_.markInAndOutInternal(projItem, startTime, endTime, markMode, matchingFrameTime, 0);
    },
    markInAndOutInMulticam: function (mediaName, normalizedMediaName, startTime, endTime, markMode, matchingFrameTime, offsetSeconds) {
        var projItem = $._PPP_.findMatchingProjectItemByItemName(mediaName);
        if (projItem === null) {
            projItem = $._PPP_.findMatchingProjectItemByItemName(normalizedMediaName);
        }
        return $._PPP_.markInAndOutInternal(projItem, startTime, endTime, markMode, matchingFrameTime, offsetSeconds);
    },
    // Specific to Jumper
    markInAndOutInternal: function (projItem, startTime, endTime, markMode, matchingFrameTime, offsetSeconds) {
        if (projItem) {
            app.enableQE();
            app.sourceMonitor.openProjectItem(projItem);
            var newTimecode = matchingFrameTime + ":00";
            var frameRate = null;

            if (offsetSeconds && offsetSeconds > 0) {
                // Find the sequence associated with the project item
                var sequence = null;
                var numSequences = app.project.sequences.numSequences;
                for (var i = 0; i < numSequences; i++) {
                    var seq = app.project.sequences[i];
                    if (seq.name === projItem.name) {
                        sequence = seq;
                        break;
                    }
                }

                if (sequence !== null) {
                    var videoDisplayFormat = sequence.videoDisplayFormat;
                    frameRate = frameRateMap[videoDisplayFormat];
                }

                // Fallback: Try to get frame rate from projectItem
                if (!frameRate) {
                    if (projItem.getFootageInterpretation) {
                        var footageInterpretation = projItem.getFootageInterpretation();
                        if (footageInterpretation && footageInterpretation.frameRate) {
                            frameRate = parseFloat(footageInterpretation.frameRate);
                        }
                    }
                }

                if (frameRate) {
                    newTimecode = $._PPP_.getTimecodeWithOffsetSeconds(matchingFrameTime, frameRate, offsetSeconds);
                }
            }

            qe.source.player.startScrubbing();
            qe.source.player.scrubTo(newTimecode);
            qe.source.player.endScrubbing();

            var inPoint = projItem.getInPoint();
            var outPoint = projItem.getOutPoint();
            var targetStartTimeSeconds = $._PPP_.getSecondsFromTimestamp(startTime)
            var targetEndTimeSeconds = $._PPP_.getSecondsFromTimestamp(endTime)
            if (offsetSeconds && offsetSeconds > 0) {
                targetStartTimeSeconds = targetStartTimeSeconds + offsetSeconds
                targetEndTimeSeconds = targetEndTimeSeconds + offsetSeconds
            }

            projItem.clearOutPoint();
            var mediaEndPoint = projItem.getOutPoint();
            const mediaDurationSeconds = mediaEndPoint.seconds
            const requestedInToOutDurationSeconds = targetEndTimeSeconds - targetStartTimeSeconds
            if (requestedInToOutDurationSeconds >= mediaDurationSeconds) {
                inPoint.seconds = 0
                projItem.setInPoint(inPoint, 4);
                projItem.setOutPoint(mediaEndPoint, 4);
                return 'Computed newTimecode: ' + newTimecode + ', Frame rate: ' + frameRate + "offsetSeconds" + offsetSeconds;
            }
            var setMarkOutAtMediaEnd = true;
            if (mediaEndPoint.seconds >= targetEndTimeSeconds) {
                outPoint.seconds = targetEndTimeSeconds;
                setMarkOutAtMediaEnd = false;
            }
            inPoint.seconds = targetStartTimeSeconds;


            const footageInterp = projItem.getFootageInterpretation();
            const fr = footageInterp.frameRate;
            if (fr) {
                if (inPoint.seconds === outPoint.seconds) {
                    const timePerFrame = 1 / fr;
                    if (inPoint.seconds > 0) {
                        inPoint.seconds = inPoint.seconds - (timePerFrame * (fr/2))
                        if (outPoint.seconds < mediaEndPoint.seconds) {
                            outPoint.seconds = outPoint.seconds + (timePerFrame * (fr/2))
                        }
                    }
                }
                if ((fr > 23 && fr < 24) || (fr > 29 && fr < 30) || (fr > 59 && fr < 60)) {
                    inPoint.seconds = inPoint.seconds / 0.9988888888888889;
                    outPoint.seconds = outPoint.seconds / 0.9988888888888889;
                }
            } else {
                if (inPoint.seconds === outPoint.seconds) {
                    if (inPoint.seconds > 0) {
                        inPoint.seconds = inPoint.seconds - 0.033;
                    } else {
                        outPoint.seconds = outPoint.seconds + 0.033;
                    }
                }
            }

            if (setMarkOutAtMediaEnd) {
                outPoint.seconds = mediaEndPoint.seconds;
                const remainderSeconds = requestedInToOutDurationSeconds - (outPoint.seconds - inPoint.seconds)
                if (remainderSeconds > 0) {
                    const newInPointSeconds = inPoint.seconds - remainderSeconds;
                    if (newInPointSeconds <= 0) {
                        inPoint.seconds = 0
                    } else {
                        inPoint.seconds = newInPointSeconds
                    }
                }
            }
            projItem.setInPoint(inPoint, 4);
            projItem.setOutPoint(outPoint, 4);

            return 'Computed newTimecode: ' + newTimecode + ', Frame rate: ' + frameRate + "offsetSeconds: " + offsetSeconds;
        } else {
            return "FAIL";
        }
    },

    // Specific to Jumper
    setShouldRefreshProjectImports: function () {
        //app.setSDKEventMessage("setShouldRefreshProjectImports triggered", 'info');
        projectImportsStatus = "UPDATED";
        return true;
    },

    // Specific to Jumper
    getShouldRefreshProjectImports: function () {
        //app.setSDKEventMessage("getShouldRefreshProjectImports triggered", 'info');
        return projectImportsStatus;
    },

    // Specific to Jumper
    getShouldRefreshProjectImportsWindows: function () {
        //app.setSDKEventMessage("getShouldRefreshProjectImportsWindows triggered", 'info');
        const currentNumberOfProjectItems = $._PPP_.getNumberOfProjectItems();
        if (currentNumberOfProjectItems !== numItemsInProjectState) {
            numItemsInProjectState = currentNumberOfProjectItems;
            projectImportsStatus = "UPDATED";
        }
        return projectImportsStatus;
    },

    // Specific to Jumper
    openProjectItem: function (mediaPath, normalizedPath) {
        //app.setSDKEventMessage("openProjectItem triggered", 'info');
        var projectItem = $._PPP_.findMatchingProjectItem(mediaPath);
        if (projectItem === null) {
            projectItem = $._PPP_.findMatchingProjectItem(normalizedPath);
        }
        app.enableQE();
        app.sourceMonitor.openProjectItem(projectItem);
        return true;
    },

    // Specific to Jumper
    alertFromPPro: function (msg) {
        //app.setSDKEventMessage("alertFromPPro triggered", 'info');
        alert(msg);
        return true;
    },

    // Specific to Jumper
    checkIsVideoExtension: function (path) {
        //app.setSDKEventMessage("checkIsVideoExtension triggered", 'info');
        const extension = path.split('.').pop().toLowerCase();
        const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'mkv', 'flv', 'm4v', 'webm', 'mxf', 'r3d', 'mpg', 'mts'];
        var isVideoExtension = false;
        for (var i = 0; i < videoExtensions.length; i++) {
            if (videoExtensions[i] === extension) {
                isVideoExtension = true;
                break;
            }
        }
        return isVideoExtension;
    },

    // Specific to Jumper
    getSourceMonitorPathAndTimestamp: function () {
        //app.setSDKEventMessage("getSourceMonitorPathAndTimestamp triggered", 'info');
        app.enableQE();
        var retval = [];

        const projectItem = app.sourceMonitor.getProjectItem();
        if (projectItem) {
            const mediaPath = projectItem.getMediaPath()
            retval.push(mediaPath);
            if ($._PPP_.checkIsVideoExtension(mediaPath)) {
                const sourceMonitorPlayerPositionSeconds = app.sourceMonitor.getPosition().seconds
                retval.push(sourceMonitorPlayerPositionSeconds.toString());
            } else {
                retval.push("0")
            }
        } else {
            const clip = qe.source.clip;
            if (clip) {
                retval.push(clip.filePath);
                if ($._PPP_.checkIsVideoExtension(clip.filePath)) {
                    const sourceMonitorPosition = qe.source.player.getPosition(); // timecode of playhead position in source monitor
                    const sourceMonitorPlayerPosSeconds = $._PPP_.parseFractionalSeconds(sourceMonitorPosition, clip.videoFrameRate);
                    retval.push(sourceMonitorPlayerPosSeconds.toString());
                } else {
                    retval.push("0")
                }
            }
        }

        return retval.join("_|&|#|e|_");
    },

    // Specific to Jumper
    getProgramMonitorPathAndTimestamp: function () {
        //app.setSDKEventMessage("getProgramMonitorPathAndTimestamp triggered", 'info');
        app.enableQE();
        var retval = [];
        var seq = app.project.activeSequence;
        var numTracks = seq.videoTracks.numTracks
        var sequencePlayerPositionSeconds = seq.getPlayerPosition().seconds; // where is playhead in sequence
        for (var j = numTracks - 1; 0 <= j; j--) {
            var actTrack = seq.videoTracks[j]
            var clipCount = actTrack.clips.numItems;
            for (var i = 0; i < clipCount; i++) {
                var actClip = actTrack.clips[i];
                var clipStartSeconds = actClip.start.seconds // when in sequence do we start
                var clipEndSeconds = actClip.end.seconds // when in sequence do we end
                var inPointSeconds = actClip.inPoint.seconds // when in source monitor did we mark in
                if (clipStartSeconds <= sequencePlayerPositionSeconds && sequencePlayerPositionSeconds < clipEndSeconds) {
                    // found matching clip from timeline opened in Program Monitor
                    const relativeTimeInClipSeconds = sequencePlayerPositionSeconds - clipStartSeconds
                    const absoluteTimeInMediaFileSeconds = inPointSeconds + relativeTimeInClipSeconds
                    const path = actClip.projectItem.getMediaPath()
                    retval.push(path);
                    const isVideoExtension = $._PPP_.checkIsVideoExtension(path)
                    if (isVideoExtension) {
                        retval.push(absoluteTimeInMediaFileSeconds.toString());
                    } else {
                        retval.push("0");
                    }
                    return retval.join("_|&|#|e|_");
                }
            }
        }

        return ""
    },

    // Specific to Jumper
    setProjectViewSelectionMatchingMediaPath: function (mediaPath, normalizedPath) {
        //app.setSDKEventMessage("setProjectViewSelectionMatchingMediaPath triggered", 'info');
        var projItem = $._PPP_.findMatchingProjectItem(mediaPath);
        if (projItem) {
            projItem.select();
        } else {
            projItem = $._PPP_.findMatchingProjectItem(normalizedPath);
            if (projItem) {
                projItem.select();
            }
        }
        return true;
    },

    insertOrAppendToTimeline: function (mediaPath, normalizedPath, targetVTrackOffset, targetATrackOffset, insertMode) {
        //app.setSDKEventMessage("insertOrAppendToTimeline triggered", 'info');
        var projItem = $._PPP_.findMatchingProjectItem(mediaPath);
        if (projItem === null) {
            projItem = $._PPP_.findMatchingProjectItem(normalizedPath);
        }
        return $._PPP_.insertOrAppendToTimelineInner(projItem, targetVTrackOffset, targetATrackOffset, insertMode);
    },

    insertOrAppendToTimelineMulticam: function (mediaName, normalizedMediaName, targetVTrackOffset, targetATrackOffset, insertMode) {
        //app.setSDKEventMessage("insertOrAppendToTimeline triggered", 'info');
        var projItem = $._PPP_.findMatchingProjectItemByItemName(mediaName);
        if (projItem === null) {
            projItem = $._PPP_.findMatchingProjectItemByItemName(normalizedMediaName);
        }
        return $._PPP_.insertOrAppendToTimelineInner(projItem, targetVTrackOffset, targetATrackOffset, insertMode);
    },

    insertOrAppendToTimelineInner: function (projItem, targetVTrackOffset, targetATrackOffset, insertMode) {
        //app.setSDKEventMessage("insertOrAppendToTimeline triggered", 'info');
        var seq = app.project.activeSequence;
        if (seq) {
            if (projItem) {
                var time = seq.getPlayerPosition();
                var videoTrackOffset = parseInt(targetVTrackOffset)
                var audioTrackOffset = parseInt(targetATrackOffset)
                var resolvedVideoTrackOffset = videoTrackOffset < seq.videoTracks.numTracks ? videoTrackOffset : 0
                var resolvedAudioTrackOffset = audioTrackOffset < seq.audioTracks.numTracks ? audioTrackOffset : 0
                if (insertMode && insertMode === "overwrite") {
                    var overwriteSuccess = seq.overwriteClip(projItem, time, resolvedVideoTrackOffset, resolvedAudioTrackOffset);
                    return projItem.name + "_|&|#|e|_" + overwriteSuccess
                } else {
                    var insertSuccess = seq.insertClip(projItem, time, resolvedVideoTrackOffset, resolvedAudioTrackOffset);
                    return projItem.name + "_|&|#|e|_" + insertSuccess
                }
            } else {
                return "no_projitem";
            }
        } else {
            return "no_sequence";
        }
    },

    getTrackCountsInActiveSequence: function () {
        var seq = app.project.activeSequence;
        if (seq) {
            return seq.videoTracks.numTracks + "_|&|#|e|_" + seq.audioTracks.numTracks
        }
        return 1 + "_|&|#|e|_" + 1; // Specific to Jumper
    }
}
