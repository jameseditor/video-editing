// ------------------------------------------------------
//
// JUMPER for Adobe Premiere Pro
//
// Gets a list of active Premiere files from Project.
//
// ------------------------------------------------------

const MAX_READY_CHECKS = 50;
const READY_CHECK_DELAY = 100;
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;
let projectImportsString = null;

function loadJSX() {
    const csInterface = new CSInterface()
    console.log('Starting to load JSX...');

    // Get the appName of the currently used application. For Premiere Pro, it's "PPRO"
    var appName = csInterface.hostEnvironment.appName;

    // Get the system path for the extension
    var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION);

    // Construct the path to the general JSX scripts (independent of appName)
    var extensionRootGeneral = extensionPath + '/jsx/';

    // Evaluate the script to load general JSX files
    csInterface.evalScript(`$._ext.evalFiles("${extensionRootGeneral}")`);

    // Construct the path to the application-specific JSX scripts
    var extensionRootApp = extensionPath + '/jsx/' + appName + '/';

    // Evaluate the script to load app-specific JSX files
    csInterface.evalScript(`$._ext.evalFiles("${extensionRootApp}")`);

    console.log('Finished loading JSX...');
}

console.log("Starting 'loadJSX' function...");
loadJSX();
console.log("'loadJSX' function completed...");

// Checks if ExtendScript API is responsive (sometimes will just give us "EvalScript error.")
function isReady() {
    return new Promise((resolve) => {
        new CSInterface().evalScript('$._PPP_.isReady()', (result) => {
            if (result && result === "OK") {
                console.log("isReady() == " + result);
                resolve(true);
            } else {
                console.log("isReady() has an error: ", result);
                resolve(false);
            }
        });
    });
}

async function waitForApiReady() {
    for (let i = 0; i < MAX_READY_CHECKS; i++) {
        if (await isReady()) {
            console.log("ExtendScript API is ready");
            return true;
        }
        await new Promise(resolve => setTimeout(resolve, READY_CHECK_DELAY));
    }
    console.error("API did not become ready in time");
    return false;
}

function fetchProjectFiles() {
    return new Promise((resolve, reject) => {
        const startTime = performance.now();
        new CSInterface().evalScript('$._PPP_.getImportedVideos()', (result) => {
            const endTime = performance.now();
            const duration = endTime - startTime;
            console.log(`getImportedVideos() returned paths in ${duration.toFixed(2)} ms`);

            if (result === "EvalScript error.") {
                console.log("getImportedVideos() returned EvalScript error.");
                reject(new Error("EvalScript error"));
            } else {
                projectImportsString = result;
                resolve(result);
            }
        });
    });
}

async function fetchProjectFilesWithRetry(maxRetries = MAX_RETRIES) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`Attempt ${attempt} of ${maxRetries}`);
            await fetchProjectFiles();
            console.log("Successfully fetched project files");
            return;
        } catch (error) {
            console.log(`Attempt ${attempt} failed: ${error.message}`);
            if (attempt === maxRetries) {
                console.error("Max retries reached. Unable to fetch project files.");
                throw error;
            }
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        }
    }
}

(async () => {
    try {
        const apiReady = await waitForApiReady();
        if (!apiReady) {
            throw new Error("API did not become ready in time");
        }
        await fetchProjectFilesWithRetry();
    } catch (error) {
        console.error("Failed to initialize or fetch project files:", error);
    }
})();